/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
/**
 * @author Patrick Stuedi <stu@zurich.ibm.com>
 *
 */

package com.ibm.net.rdma.jverbs.rping;

import java.nio.ByteBuffer;
import java.util.LinkedList;
import com.ibm.net.rdma.jverbs.verbs.*;

class RdmaDataPath {
    public static boolean CachingON = false;

    public static int MAX_SGE = 1;
    public static int MAX_WR = 100;

    private PostSendMethod preparePostSendCall;
    private PostReceiveMethod postRecvCall;
    private RequestNotifyCQMethod reqNotifyCall;
    private PollCQMethod pollCqCall;
    private WorkCompletion[] wcList;

    private QueuePair qp;
    private CompletionChannel compChannel;
    private CompletionQueue cq;

    public RdmaDataPath(VerbsContext context, CompletionChannel compChannel, QueuePair qp, CompletionQueue cq) {
        this.preparePostSendCall = null;
        this.postRecvCall = null;
        this.reqNotifyCall = null;
        this.pollCqCall = null;
        this.compChannel = compChannel;
        this.qp = qp;
        this.cq = cq;
    }

    public boolean send(ByteBuffer[] fragments, LinkedList<SendWorkRequest> wrList, boolean signaled, boolean polling)
            throws Exception {
        for (int i = 0; i < fragments.length; i++) {
            ByteBuffer buffer = fragments[i];
            buffer.clear();
        }

        preparePostSendCall = getPostSendMethodCall(wrList);
        preparePostSendCall.execute();

        if (preparePostSendCall.isSuccess() == true) {
            if (signaled) {
                return checkCq(wrList.size(), polling);
            }
        }

        return false;
    }

    public boolean initSGRecv(LinkedList<ReceiveWorkRequest> wrList) throws Exception {
        postRecvCall = getPostRecvCall(wrList);
        postRecvCall.execute();

        return postRecvCall.isSuccess();
    }

    public boolean completeSGRecv(LinkedList<ReceiveWorkRequest> wrList, boolean polling) throws Exception {
        return checkCq(wrList.size(), polling);
    }

    private boolean checkCq(int expectedElements, boolean polling) throws Exception {
        boolean success = false;
        int elementsRead = 0;

        while (true) {
            if (!polling) {
                reqNotifyCall = getReqNotifyCall();
                reqNotifyCall.execute();
            }

            pollCqCall = getPollCqCall(1);
            int res = pollCqCall.execute().getPolls();
            if (res < 0) {
                break;
            } else if (res > 0) {
                elementsRead += res;
                compChannel.ackCQEvents(cq, res);
                if (wcList[0].getStatus() != WorkCompletion.Status.IBV_WC_SUCCESS) {
                    if (Rping.debug)
                        System.out.println("Work Completion Event Recevied: wr id : " + wcList[0].getWorkRequestId()
                                + "   > Opcode: " + wcList[0].getOpcode() + "   > Status: " + wcList[0].getStatus());
                    break;
                } else {
                    if (Rping.debug)
                        System.out.println("Work Completion Event Recevied: wr id : " + wcList[0].getWorkRequestId()
                                + "   > Opcode: " + wcList[0].getOpcode() + "   > Status: " + wcList[0].getStatus());
                }
            } else {
                if (!polling) {
                	compChannel.getCQEvent(-1);
                }
            }

            if (elementsRead >= expectedElements) {
                success = true;
                break;
            }
        }
        return success;
    }

    private PostSendMethod getPostSendMethodCall(LinkedList<SendWorkRequest> wrList) throws Exception {
        if (CachingON == false || this.preparePostSendCall == null || !preparePostSendCall.isValid()) {
            this.preparePostSendCall = qp.preparePostSend(wrList);
        }
        return preparePostSendCall;
    }

    private PostReceiveMethod getPostRecvCall(LinkedList<ReceiveWorkRequest> wrList) throws Exception {
        if (CachingON == false || postRecvCall == null || !postRecvCall.isValid()) {
            postRecvCall = qp.preparePostReceive(wrList);
        }
        return postRecvCall;
    }

    private RequestNotifyCQMethod getReqNotifyCall() throws Exception {
        if (CachingON == false || reqNotifyCall == null || !reqNotifyCall.isValid()) {
            reqNotifyCall = cq.requestNotifyCQ(false);
        }
        return reqNotifyCall;
    }

    private PollCQMethod getPollCqCall(int size) throws Exception {
        if (CachingON == false || pollCqCall == null || !pollCqCall.isValid()) {
            wcList = new WorkCompletion[size];
            for (int i = 0; i < size; i++) {
                wcList[i] = new WorkCompletion();
            }
            pollCqCall = cq.pollCQ(wcList, size);
        }
        return pollCqCall;
    }
}
