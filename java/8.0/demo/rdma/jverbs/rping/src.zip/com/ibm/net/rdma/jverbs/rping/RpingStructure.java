/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.rping;

import java.nio.ByteBuffer;

import com.ibm.net.rdma.jverbs.cm.ConnectionId;
import com.ibm.net.rdma.jverbs.cm.EventChannel;
import com.ibm.net.rdma.jverbs.verbs.CompletionChannel;
import com.ibm.net.rdma.jverbs.verbs.CompletionQueue;
import com.ibm.net.rdma.jverbs.verbs.MemoryRegion;
import com.ibm.net.rdma.jverbs.verbs.ProtectionDomain;
import com.ibm.net.rdma.jverbs.verbs.QueuePair;

class RpingStructure {
    boolean server; /* false if client */

    CompletionChannel channel;
    CompletionQueue cq;
    ProtectionDomain pd;
    QueuePair qp;

    ByteBuffer recvBuf;
    MemoryRegion recvMr;

    ByteBuffer sendBuf;
    MemoryRegion sendMr;

    ByteBuffer rdmaBuf; /* used as rdma sink */
    MemoryRegion rdmaMr;

    ByteBuffer startBuf; /* rdma read src */
    MemoryRegion startMr;

    int remoteRkey; /* remote buffers RKEY */
    long remoteAddr; /* remote buffers ADDR */
    int remoteLen; /* remote buffers LENGTH */

    int port; /* port to bind/connect */
    boolean verbose; /* verbose logging */
    int count; /* ping count */
    int size; /* ping data size */
    boolean validate; /* validate ping data */

    EventChannel cmChannel;
    ConnectionId cmId; /* connection on client side, */

    ConnectionId childCmId; /* connection on server side */
    String ipAddress;
}
