/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.rping;


final class Rping {
    static boolean debug = false;
    static int RPING_SQ_DEPTH = 16;
    static String RPING_MSG_FMT = "rdma-ping-%d: ";
    private static int RPING_MIN_BUFSIZE = 16;

    private RpingStructure cb;

    private void usage() {
        System.err.printf("Rping -s [-vVd] [-S size] [-C count] [-a addr] [-p port]\n");
        System.err.printf("Rping -c [-vVd] [-S size] [-C count] -a addr [-p port]\n");
        System.err.printf("\t-c\t\tclient side\n");
        System.err.printf("\t-s\t\tserver side\n");
        System.err.printf("\t-v\t\tdisplay ping data to stdout\n");
        System.err.printf("\t-V\t\tvalidate ping data\n");
        System.err.printf("\t-d\t\tdebug printfs\n");
        System.err.printf("\t-S size \tping data size\n");
        System.err.printf("\t-C count\tping count times\n");
        System.err.printf("\t-a addr\t\taddress\n");
        System.err.printf("\t-p port\t\tport\n");
    }

    private int mainMethod(String[] args) throws Exception {
        int ret = 0;

        cb = new RpingStructure();

        boolean serverSet = false;
        cb.server = false;
        cb.size = 64 * 2;
        cb.ipAddress = "";
        cb.port = 7174;
        cb.count = 0;

        GetOpt go = new GetOpt(args, "a:Pp:C:S:t:scvVd");
        go.optErr = true;
        int op = -1;

        while ((op = go.getopt()) != GetOpt.optEOF) {
            switch (op) {
            case 'a':
                cb.ipAddress = go.optArgGet();
                break;
            case 'p':
                cb.port = Integer.parseInt(go.optArgGet());
                if (debug) {
                    System.out.printf("port %d\n", cb.port);
                }
                break;
            case 's':
                serverSet = true;
                cb.server = true;
                if (debug) {
                    System.out.printf("server\n");
                }
                break;
            case 'c':
                serverSet = true;
                cb.server = false;
                if (debug) {
                    System.out.printf("client\n");
                }
                break;
            case 'S':
                cb.size = Integer.parseInt(go.optArgGet());
                cb.size = cb.size * 2;
                if (cb.size < RPING_MIN_BUFSIZE) {
                    System.err.printf("Invalid size (minimum is %d) ", RPING_MIN_BUFSIZE);
                    ret = -1;
                } else if (debug) {
                    System.out.printf("size %d\n", cb.size);
                }
                break;
            case 'C':
                cb.count = Integer.parseInt(go.optArgGet());
                if (cb.count < 0) {
                    System.err.printf("Invalid count %d\n", cb.count);
                    ret = -1;
                } else if (debug) {
                    System.out.printf("count %d\n", (int) cb.count);
                }
                break;
            case 'v':
                cb.verbose = true;
                if (debug) {
                    System.out.printf("verbose\n");
                }
                break;
            case 'V':
                cb.validate = true;
                if (debug) {
                    System.out.printf("validate data\n");
                }
                break;
            case 'd':
                debug = true;
                break;
            default:
                usage();
                ret = -1;
                return ret;
            }
        }

        if (ret < 0) {
            return ret;
        }

        if (!serverSet) {
            usage();
            ret = -1;
            return -1;
        }

        if (cb.server) {
            RpingServer rserver = new RpingServer(cb);
            rserver.run();
        } else {
            RpingClient rclient = new RpingClient(cb);
            rclient.run();
        }

        if (debug) {
            System.out.printf("destroy cm_id %s\n", cb.cmId.toString());
        }
        try {
            cb.cmId.destroy();
        } catch (Exception e) {
        }
        return ret;
    }

    public static void main(String[] args) throws Exception {
        new Rping().mainMethod(args);
    }
}
