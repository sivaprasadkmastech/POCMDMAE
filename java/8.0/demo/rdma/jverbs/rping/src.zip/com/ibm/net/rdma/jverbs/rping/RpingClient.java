/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.rping;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.LinkedList;

import com.ibm.net.rdma.jverbs.cm.ConnectionEvent;
import com.ibm.net.rdma.jverbs.cm.ConnectionId;
import com.ibm.net.rdma.jverbs.cm.ConnectionParameter;
import com.ibm.net.rdma.jverbs.cm.EventChannel;
import com.ibm.net.rdma.jverbs.cm.PortSpace;
import com.ibm.net.rdma.jverbs.verbs.VerbsContext;
import com.ibm.net.rdma.jverbs.verbs.MemoryRegion;
import com.ibm.net.rdma.jverbs.verbs.QueuePairInitAttribute;
import com.ibm.net.rdma.jverbs.verbs.QueuePair;
import com.ibm.net.rdma.jverbs.verbs.ReceiveWorkRequest;
import com.ibm.net.rdma.jverbs.verbs.SendWorkRequest;
import com.ibm.net.rdma.jverbs.verbs.ScatterGatherElement;

class RpingClient {
    public RpingStructure cb;
    public RdmaDataPath commRdma = null;
    LinkedList<ReceiveWorkRequest> wrList_recv = null;

    public RpingClient(RpingStructure cb) {
        this.cb = cb;
    }

    public void run() throws Exception {
        System.out.println("VerbsClient::starting...");

        // create a communication channel for receiving CM events
        cb.cmChannel = EventChannel.createEventChannel();
        if (cb.cmChannel == null) {
            System.out.println("VerbsClient::cmChannel null");
            return;
        }

        // create a ConnectionId for this client
        cb.cmId = ConnectionId.create(cb.cmChannel, PortSpace.RDMA_PS_TCP);
        if (cb.cmId == null) {
            System.out.println("VerbsClient::id null");
            return;
        }

        // before connecting, we have to resolve addresses
        InetAddress _dst = InetAddress.getByName(cb.ipAddress);
        InetSocketAddress dst = new InetSocketAddress(_dst, cb.port);
        cb.cmId.resolveAddress(null, dst, 2000);
        if (Rping.debug) {
            System.out.println("Resolved server address " + cb.ipAddress + " on port " + cb.port);
        }

        // resolve addr returns an event, we have to catch that event
        ConnectionEvent cmEvent = cb.cmChannel.getConnectionEvent(-1);
        if (cmEvent == null) {
            System.out.println("VerbsClient::cmEvent null");
            return;
        } else if (cmEvent.getEventType() != ConnectionEvent.EventType.RDMA_CM_EVENT_ADDR_RESOLVED) {
            System.out.println("VerbsClient::wrong event received: " + cmEvent.getEventType());
            return;
        }
        cb.cmChannel.ackConnectionEvent(cmEvent);

        // we also have to resolve the route
        cb.cmId.resolveRoute(2000);

        if (Rping.debug) {
            System.out.println("Resolved route to server");
        }

        // and catch that event too
        cmEvent = cb.cmChannel.getConnectionEvent(-1);
        if (cmEvent == null) {
            System.out.println("VerbsClient::cmEvent null");
            return;
        } else if (cmEvent.getEventType() != ConnectionEvent.EventType.RDMA_CM_EVENT_ROUTE_RESOLVED) {
            System.out.println("VerbsClient::wrong event received: " + cmEvent.getEventType());
            return;
        }
        cb.cmChannel.ackConnectionEvent(cmEvent);

        // let's create a device context
        VerbsContext context = cb.cmId.getVerbsContext();

        // and a protection domain, we use that one later for registering memory
        cb.pd = context.allocProtectionDomain();
        if (cb.pd == null) {
            System.out.println("VerbsClient::pd null");
            return;
        }

        // the comp channel is used for getting CQ events
        cb.channel = context.createCompletionChannel();
        if (cb.channel == null) {
            System.out.println("VerbsClient::compChannel null");
            return;
        }

        // let's create a completion queue
        cb.cq = context.createCompletionQueue(cb.channel, 50, 0);
        if (cb.cq == null) {
            System.out.println("VerbsClient::cq null");
            return;
        }
        // and request to be notified for this queue
        cb.cq.requestNotifyCQ(false).execute().free();

        // we prepare for the creation of a queue pair (QP)
        QueuePairInitAttribute attr = new QueuePairInitAttribute();
        attr.getCap().setMaxReceiveSge(1);
        attr.getCap().setMaxReceiveWorkRequest(10);
        attr.getCap().setMaxSendSge(1);
        attr.getCap().setMaxSendWorkRequest(10);
        attr.setQueuePairType(QueuePair.Type.IBV_QPT_RC);
        attr.setReceiveCompletionQueue(cb.cq);
        attr.setSendCompletionQueue(cb.cq);
        // let's create a queue pair
        cb.qp = cb.cmId.createQueuePair(cb.pd, attr);
        if (cb.qp == null) {
            System.out.println("VerbsClient::qp null");
            return;
        }

        rping_setup_buffers();
        commRdma = new RdmaDataPath(context, cb.channel, cb.qp, cb.cq);

        wrList_recv = postRecvCall(cb.recvMr);

        // now let's connect to the server
        ConnectionParameter connParam = new ConnectionParameter();
        connParam.setInitiatorDepth((byte) 1);
        connParam.setResponderResources((byte) 1);
        connParam.setRetryCount((byte) 7);
        cb.cmId.connect(connParam);

        // wait until we are really connected
        cmEvent = cb.cmChannel.getConnectionEvent(-1);
        if (cmEvent == null) {
            System.out.println("VerbsClient::cmEvent null");
            return;
        } else if (cmEvent.getEventType() != ConnectionEvent.EventType.RDMA_CM_EVENT_ESTABLISHED) {
            System.out.println("VerbsClient::wrong event received: " + cmEvent.getEventType());
            return;
        }
        cb.cmChannel.ackConnectionEvent(cmEvent);
        if (Rping.debug) {
            System.out.println("Connected to server");
        }

        rping_test_client();
        try {
            cb.cmId.destroy();
        } catch (Exception e) {
        }
    }

    public int rping_setup_buffers() throws Exception {
        int buffersize = 1024;
        int access = MemoryRegion.IBV_ACCESS_LOCAL_WRITE | MemoryRegion.IBV_ACCESS_REMOTE_WRITE
                | MemoryRegion.IBV_ACCESS_REMOTE_READ;

        cb.recvBuf = ByteBuffer.allocateDirect(buffersize);
        cb.recvMr = cb.pd.registerMemoryRegion(cb.recvBuf, access).execute().free().getMemoryRegion();
        if (cb.recvMr == null) {
            System.err.println("recv_buf reg_mr failed\n");
            return -1;
        }

        cb.sendBuf = ByteBuffer.allocateDirect(buffersize);
        cb.sendMr = cb.pd.registerMemoryRegion(cb.sendBuf, access).execute().free().getMemoryRegion();
        if (cb.sendMr == null) {
            System.err.println("send_buf reg_mr failed\n");
            return -1;
        }

        cb.rdmaBuf = ByteBuffer.allocateDirect(buffersize);
        cb.rdmaMr = cb.pd.registerMemoryRegion(cb.rdmaBuf, access).execute().free().getMemoryRegion();
        if (cb.rdmaMr == null) {
            System.err.println("rdma_buf reg_mr failed\n");
            return -1;
        }

        if (!cb.server) {
            cb.startBuf = ByteBuffer.allocateDirect(buffersize);
            cb.startMr = cb.pd.registerMemoryRegion(cb.startBuf, access).execute().free().getMemoryRegion();
            if (cb.startMr == null) {
                System.err.println("start_buf reg_mr failed\n");
                return -1;
            }
        }
        return 0;
    }

    public int rping_test_client() throws Exception {
        int ping, start, cc, i, ret = 0;
        int c;
        StringBuffer sb = null;

        start = 65;

        ping = 0;
        System.out.println("cb.count:" + cb.count);

        while (true) {
            if (cb.count != 0 && ping >= cb.count) {
                break;
            }

            /* Put some ascii text in the buffer. */
            String putSring = "rdma-ping-" + ping + ": ";

            sb = new StringBuffer();
            sb.append(putSring);
            cc = putSring.length();
            for (i = cc, c = start; i < cb.size / 2; i++) {
                sb.append(new Character((char) c).toString());
                c++;
                if (c > 122)
                    c = 65;
            }
            start++;
            if (start > 122)
                start = 65;

            cb.startBuf.clear();
            cb.startBuf.asCharBuffer().put(sb.toString());
            // System.out.println("start_buf :" + cb.startBuf.asCharBuffer().toString() );
            // cb.startBuf.clear();

            cb.sendBuf.clear();
            cb.sendBuf.putLong(cb.startMr.getAddress());
            cb.sendBuf.putInt(cb.startMr.getLength());
            cb.sendBuf.putInt(cb.startMr.getLocalKey());
            cb.sendBuf.clear();

            if (Rping.debug) {
                System.out.println("RDMA addr " + cb.startMr.getAddress() + " rkey " + cb.startMr.getLocalKey()
                        + " len " + cb.startMr.getLength() + "\n");
            }

            // rearm postrecv
            wrList_recv = postRecvCall(cb.recvMr);

            // rping_format_send(cb, cb.start_buf, cb.start_mr);
            preparePostSendCall(cb.sendMr, new ByteBuffer[] { cb.startBuf });

            /* Wait for server to ACK */
            commRdma.completeSGRecv(this.wrList_recv, false);
            if (Rping.debug) {
                System.out.println("recv completion");
            }

            cb.sendBuf.clear();
            cb.sendBuf.putLong(cb.rdmaMr.getAddress());
            cb.sendBuf.putInt(cb.rdmaMr.getLength());
            cb.sendBuf.putInt(cb.rdmaMr.getLocalKey());
            cb.sendBuf.clear();

            // rearm postrecv
            wrList_recv = postRecvCall(cb.recvMr);

            // rping_format_send(cb, cb.rdma_buf, cb.rdma_mr);
            preparePostSendCall(cb.sendMr, new ByteBuffer[] { cb.rdmaBuf });

            /* Wait for server to ACK */
            commRdma.completeSGRecv(this.wrList_recv, false);
            if (Rping.debug) {
                System.out.println("recv completion");
            }

            if (cb.validate) {
                String startbuf = cb.startBuf.asCharBuffer().toString();
                String rdmabuf = cb.rdmaBuf.asCharBuffer().toString();

                if (startbuf.length() != rdmabuf.length() && !startbuf.equals(rdmabuf)) {
                    System.err.println("data mismatch!\n");
                    ret = -1;
                    break;
                }
            }

            if (cb.verbose)
                System.out.printf("ping data: %s\n", cb.rdmaBuf.asCharBuffer().toString());
            ping++;
        }

        return ret;
    }

    public boolean preparePostSendCall(MemoryRegion sendMr, ByteBuffer[] buffers) throws Exception {
        ScatterGatherElement sgeSend = new ScatterGatherElement();
        sgeSend.setAddress(sendMr.getAddress());
        sgeSend.setLength(sendMr.getLength());
        sgeSend.setLocalKey(sendMr.getLocalKey());
        LinkedList<ScatterGatherElement> sgeList = new LinkedList<ScatterGatherElement>();
        sgeList.add(sgeSend);
        SendWorkRequest sendWR = new SendWorkRequest();
        sendWR.setWorkRequestId(2000);
        sendWR.setSgeList(sgeList);
        sendWR.setOpcode(SendWorkRequest.Opcode.IBV_WR_SEND);
        sendWR.setSendFlags(SendWorkRequest.IBV_SEND_SIGNALED);
        LinkedList<SendWorkRequest> wrList_send = new LinkedList<SendWorkRequest>();
        wrList_send.add(sendWR);
        if (!commRdma.send(buffers, wrList_send, true, false)) {
            if (Rping.debug) {
                System.out.println("send failed");
            }
            return false;
        } else {
            if (Rping.debug) {
                System.out.printf("send completion\n");
            }
        }

        return true;
    }

    public LinkedList<ReceiveWorkRequest> postRecvCall(MemoryRegion recvMr) throws Exception {
        // let's prepare some work requests for receiving
        ScatterGatherElement sgeRecv = new ScatterGatherElement();
        sgeRecv.setAddress(recvMr.getAddress());
        sgeRecv.setLength(recvMr.getLength());
        int lkey = recvMr.getLocalKey();
        sgeRecv.setLocalKey(lkey);
        LinkedList<ScatterGatherElement> sgeListRecv = new LinkedList<ScatterGatherElement>();
        sgeListRecv.add(sgeRecv);
        ReceiveWorkRequest recvWR = new ReceiveWorkRequest();
        recvWR.setSgeList(sgeListRecv);
        recvWR.setWorkRequestId(2001);
        LinkedList<ReceiveWorkRequest> wrList_recv = new LinkedList<ReceiveWorkRequest>();
        wrList_recv.add(recvWR);

        // post a receive call
        commRdma.initSGRecv(wrList_recv);
        return wrList_recv;
    }
}
