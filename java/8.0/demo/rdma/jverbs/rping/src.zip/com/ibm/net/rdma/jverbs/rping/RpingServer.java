/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.rping;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedList;

import com.ibm.net.rdma.jverbs.cm.ConnectionEvent;
import com.ibm.net.rdma.jverbs.cm.ConnectionId;
import com.ibm.net.rdma.jverbs.cm.ConnectionParameter;
import com.ibm.net.rdma.jverbs.cm.EventChannel;
import com.ibm.net.rdma.jverbs.cm.PortSpace;
import com.ibm.net.rdma.jverbs.verbs.VerbsContext;
import com.ibm.net.rdma.jverbs.verbs.MemoryRegion;
import com.ibm.net.rdma.jverbs.verbs.QueuePairInitAttribute;
import com.ibm.net.rdma.jverbs.verbs.QueuePair;
import com.ibm.net.rdma.jverbs.verbs.ReceiveWorkRequest;
import com.ibm.net.rdma.jverbs.verbs.SendWorkRequest;
import com.ibm.net.rdma.jverbs.verbs.ScatterGatherElement;

/**
 * Rping server
 *
 */
class RpingServer {
    public RpingStructure cb;
    public RdmaDataPath commRdma = null;
    LinkedList<ReceiveWorkRequest> wrRecvList = null;

    public RpingServer(RpingStructure cb) {
        this.cb = cb;
    }

    public void run() throws Exception {
        System.out.println("VerbsServer::starting...");
        // create a communication channel for receiving CM events
        cb.cmChannel = EventChannel.createEventChannel();
        if (cb.cmChannel == null) {
            System.out.println("VerbsServer::CM channel null");
            return;
        }

        // create a ConnectionId for the server
        cb.cmId = ConnectionId.create(cb.cmChannel, PortSpace.RDMA_PS_TCP);
        if (cb.cmId == null) {
            System.out.println("idPriv null");
            return;
        }

        if (cb.ipAddress.length() < 1) {
            cb.ipAddress = retrieveIPV4AddressOfIBInterfaceByName("ib0");
            if (cb.ipAddress.equals("")) {
                cb.ipAddress = retrieveIPV4AddressOfIBInterfaceByName("ib1");
            }
            if (cb.ipAddress.equals("")) {
                System.out
                        .println("Not able fetch the Infiniband interface address. Hence exiting. Use -a option to pass the IB address");
                return;
            }
        }
        if (Rping.debug) {
            System.out.println("Binding to : " + cb.ipAddress);
        }
        InetAddress _src = InetAddress.getByName(cb.ipAddress);
        InetSocketAddress src = new InetSocketAddress(_src, cb.port);
        cb.cmId.bindAddress(src);
        if (Rping.debug) {
            System.out.println("Bind to " + cb.ipAddress + " on port " + cb.port + " successful");
        }

        // listen on the id
        cb.cmId.listen(10);
        if (Rping.debug) {
            System.out.println("listening...");
        }

        // wait for new connect requests
        ConnectionEvent cmEvent = cb.cmChannel.getConnectionEvent(-1);
        if (cmEvent == null) {
            System.out.println("cmEvent null");
            return;
        } else if (cmEvent.getEventType() != ConnectionEvent.EventType.RDMA_CM_EVENT_CONNECT_REQUEST) {
            System.out.println("VerbsServer::wrong event received: " + cmEvent.getEventType());
            return;
        }
        // always acknowledge CM events
        cb.cmChannel.ackConnectionEvent(cmEvent);

        // get the id of the newly connection
        cb.childCmId = cmEvent.getConnectionId();
        if (cb.childCmId == null) {
            System.out.println("VerbsServer::connId null");
            return;
        }

        // get the device context of the new connection, typically the same as
        // with the server id
        VerbsContext context = cb.childCmId.getVerbsContext();
        if (context == null) {
            System.out.println("VerbsServer::context null");
            return;
        }

        // create a new protection domain, we will use the pd later when
        // registering memory
        cb.pd = context.allocProtectionDomain();
        if (cb.pd == null) {
            System.out.println("VerbsServer::pd null");
            return;
        }

        // the comp channel is used to get CQ notifications
        cb.channel = context.createCompletionChannel();
        if (cb.channel == null) {
            System.out.println("VerbsServer::compChannel null");
            return;
        }

        // create a completion queue
        cb.cq = context.createCompletionQueue(cb.channel, 50, 0);
        if (cb.cq == null) {
            System.out.println("VerbsServer::cq null");
            return;
        }
        // request to be notified on that CQ
        cb.cq.requestNotifyCQ(false).execute().free();

        // prepare a new queue pair
        QueuePairInitAttribute attr = new QueuePairInitAttribute();
        attr.getCap().setMaxReceiveSge(1);
        attr.getCap().setMaxReceiveWorkRequest(10);
        attr.getCap().setMaxSendSge(1);
        attr.getCap().setMaxSendWorkRequest(Rping.RPING_SQ_DEPTH);
        attr.setQueuePairType(QueuePair.Type.IBV_QPT_RC);
        attr.setReceiveCompletionQueue(cb.cq);
        attr.setSendCompletionQueue(cb.cq);
        // create the queue pair for the client connection
        cb.qp = cb.childCmId.createQueuePair(cb.pd, attr);
        if (cb.qp == null) {
            System.out.println("VerbsServer::qp null");
            return;
        }

        rping_setup_buffers();

        ConnectionParameter connParam = new ConnectionParameter();
        connParam.setInitiatorDepth((byte) 1);
        connParam.setResponderResources((byte) 1);
        connParam.setRetryCount((byte) 7);
        // once the client id is set up, accept the connection
        cb.childCmId.accept(connParam);

        // wait until the connection is officially switched into established mode
        cmEvent = cb.cmChannel.getConnectionEvent(-1);
        if (cmEvent.getEventType() != ConnectionEvent.EventType.RDMA_CM_EVENT_ESTABLISHED) {
            System.out.println("VerbsServer::wrong event received: " + cmEvent.getEventType());
            return;
        }
        // always ack CM events
        cb.cmChannel.ackConnectionEvent(cmEvent);

        commRdma = new RdmaDataPath(context, cb.channel, cb.qp, cb.cq);

        wrRecvList = postRecvCall(cb.recvMr);

        Thread monitor = new Thread() {
            public void run() {
                while (true) {
                    ConnectionEvent cmEvent;
                    try {
                        cmEvent = cb.cmChannel.getConnectionEvent(-1);
                        if (cmEvent == null) {
                            System.out.println("cmEvent null");
                            return;
                        }
                        cb.cmChannel.ackConnectionEvent(cmEvent);
                        if (cmEvent.getEventType() == ConnectionEvent.EventType.RDMA_CM_EVENT_DISCONNECTED) {
                            System.out.println("VerbsServer::peer disconnected.\n");
                            System.exit(0);
                        }
                    } catch (Exception e) {
                    }
                }
            }
        };
        monitor.start();

        rping_test_server();
        cb.childCmId.destroy();
    }

    public int rping_setup_buffers() throws Exception {
        int buffersize = 1024;
        int access = MemoryRegion.IBV_ACCESS_LOCAL_WRITE | MemoryRegion.IBV_ACCESS_REMOTE_WRITE
                | MemoryRegion.IBV_ACCESS_REMOTE_READ;

        cb.recvBuf = ByteBuffer.allocateDirect(buffersize);
        cb.recvMr = cb.pd.registerMemoryRegion(cb.recvBuf, access).execute().free().getMemoryRegion();
        if (cb.recvMr == null) {
            System.err.println("recv_buf reg_mr failed\n");
            return -1;
        }

        cb.sendBuf = ByteBuffer.allocateDirect(buffersize);
        cb.sendMr = cb.pd.registerMemoryRegion(cb.sendBuf, access).execute().free().getMemoryRegion();
        if (cb.sendMr == null) {
            System.err.println("send_buf reg_mr failed\n");
            return -1;
        }

        cb.rdmaBuf = ByteBuffer.allocateDirect(buffersize);
        cb.rdmaMr = cb.pd.registerMemoryRegion(cb.rdmaBuf, access).execute().free().getMemoryRegion();
        if (cb.rdmaMr == null) {
            System.err.println("rdma_buf reg_mr failed\n");
            return -1;
        }

        if (!cb.server) {
            cb.startBuf = ByteBuffer.allocateDirect(buffersize);
            cb.startMr = cb.pd.registerMemoryRegion(cb.startBuf, access).execute().free().getMemoryRegion();
            if (cb.startMr == null) {
                System.err.println("start_buf reg_mr failed\n");
                return -1;
            }
        }

        return 0;
    }

    public int server_recv() throws Exception {
        if (Rping.debug) {
            System.out.printf("recv completion\n");
        }

        cb.recvBuf.clear();
        cb.remoteAddr = cb.recvBuf.getLong();
        cb.remoteLen = cb.recvBuf.getInt();
        cb.remoteRkey = cb.recvBuf.getInt();
        cb.recvBuf.clear();

        if (Rping.debug) {
            System.out
                    .printf("Received rkey %d addr %d len %d from peer\n", cb.remoteRkey, cb.remoteAddr, cb.remoteLen);
        }
        return 0;
    }

    public int rping_test_server() throws Exception {
        while (true) {
            commRdma.completeSGRecv(this.wrRecvList, false);
            server_recv();

            if (Rping.debug) {
                System.out.printf("server received sink adv\n");
            }

            /* Issue RDMA Read. */
            preparePostSendRdmaCall(0, cb.rdmaMr, cb.remoteAddr, cb.remoteRkey, new ByteBuffer[] { cb.rdmaBuf });
            if (Rping.debug) {
                System.out.printf("server posted rdma read req \n");
            }

            /* Display data in recv buf */
            if (cb.verbose)
                System.out.printf("server ping data: %s\n", cb.rdmaBuf.asCharBuffer().toString());

            // rearm for next recv operation
            this.wrRecvList = postRecvCall(cb.recvMr);

            /* Tell client to continue */
            preparePostSendCall(cb.sendMr, new ByteBuffer[] { cb.sendBuf });
            if (Rping.debug) {
                System.out.printf("server posted go ahead\n");
            }

            /* Wait for client's RDMA STAG/TO/Len */
            commRdma.completeSGRecv(this.wrRecvList, false);
            server_recv();

            if (Rping.debug) {
                System.out.printf("server received sink adv\n");
            }

            /* RDMA Write echo data */
            preparePostSendRdmaCall(1, cb.rdmaMr, cb.remoteAddr, cb.remoteRkey, new ByteBuffer[] { cb.rdmaBuf });
            if (Rping.debug) {
                System.out.printf("server rdma write complete \n");
            }

            // rearm for next recv operation
            this.wrRecvList = postRecvCall(cb.recvMr);

            preparePostSendCall(cb.sendMr, new ByteBuffer[] { cb.sendBuf });
            if (Rping.debug) {
                System.out.printf("server posted Done\n");
            }
        }
    }

    public boolean preparePostSendRdmaCall(int type, MemoryRegion sendMr, long remoteAddr, int remotelkey,
            ByteBuffer[] buffers) throws Exception {
        // if type=0 : RDMA_READ , type=1 RDMA_WRITE
        ScatterGatherElement sgeSend = new ScatterGatherElement();
        sgeSend.setAddress(sendMr.getAddress());
        sgeSend.setLength(sendMr.getLength());
        sgeSend.setLocalKey(sendMr.getLocalKey());
        LinkedList<ScatterGatherElement> sgeList = new LinkedList<ScatterGatherElement>();
        sgeList.add(sgeSend);
        SendWorkRequest sendWR = new SendWorkRequest();
        sendWR.setWorkRequestId(2000);
        sendWR.setSgeList(sgeList);
        sendWR.setOpcode(type == 0 ? SendWorkRequest.Opcode.IBV_WR_RDMA_READ : SendWorkRequest.Opcode.IBV_WR_RDMA_WRITE);
        sendWR.setSendFlags(SendWorkRequest.IBV_SEND_SIGNALED);
        sendWR.getRdma().setRemoteAddress(remoteAddr);
        sendWR.getRdma().setRemoteKey(remotelkey);
        LinkedList<SendWorkRequest> wrList_send = new LinkedList<SendWorkRequest>();
        wrList_send.add(sendWR);
        if (!commRdma.send(buffers, wrList_send, true, false)) {
            if (Rping.debug) {
                System.out.println("Failed to post RDMA " + (type == 0 ? "READ" : "WRITE"));
            }
            return false;
        } else {
            if (Rping.debug) {
                System.out.println("rdma read " + (type == 0 ? "read" : "write") + "completion");
            }
        }
        return true;
    }

    public boolean preparePostSendCall(MemoryRegion sendMr, ByteBuffer[] buffers) throws Exception {
        ScatterGatherElement sgeSend = new ScatterGatherElement();
        sgeSend.setAddress(sendMr.getAddress());
        sgeSend.setLength(sendMr.getLength());
        sgeSend.setLocalKey(sendMr.getLocalKey());
        LinkedList<ScatterGatherElement> sgeList = new LinkedList<ScatterGatherElement>();
        sgeList.add(sgeSend);
        SendWorkRequest sendWR = new SendWorkRequest();
        sendWR.setWorkRequestId(2000);
        sendWR.setSgeList(sgeList);
        sendWR.setOpcode(SendWorkRequest.Opcode.IBV_WR_SEND);
        sendWR.setSendFlags(SendWorkRequest.IBV_SEND_SIGNALED);
        LinkedList<SendWorkRequest> wrList_send = new LinkedList<SendWorkRequest>();
        wrList_send.add(sendWR);
        if (!commRdma.send(buffers, wrList_send, true, false)) {
            if (Rping.debug) {
                System.out.println("send failed");
            }
            return false;
        } else {
            if (Rping.debug) {
                System.out.printf("send completion\n");
            }
        }
        return true;
    }

    public LinkedList<ReceiveWorkRequest> postRecvCall(MemoryRegion recvMr) throws Exception {
        // let's prepare some work requests for receiving
        ScatterGatherElement sgeRecv = new ScatterGatherElement();
        sgeRecv.setAddress(recvMr.getAddress());
        sgeRecv.setLength(recvMr.getLength());
        int lkey = recvMr.getLocalKey();
        sgeRecv.setLocalKey(lkey);
        LinkedList<ScatterGatherElement> sgeListRecv = new LinkedList<ScatterGatherElement>();
        sgeListRecv.add(sgeRecv);
        ReceiveWorkRequest recvWR = new ReceiveWorkRequest();
        recvWR.setSgeList(sgeListRecv);
        recvWR.setWorkRequestId(2001);
        LinkedList<ReceiveWorkRequest> wrList_recv = new LinkedList<ReceiveWorkRequest>();
        wrList_recv.add(recvWR);

        // post a receive call
        commRdma.initSGRecv(wrList_recv);
        return wrList_recv;
    }

    /**
     * retrieves the ipv4 address of infiniband interface of the given name
     * 
     * @param ibname
     * @return ipv4 address of given infiniband interface name
     * @throws SocketException
     */
    public static String retrieveIPV4AddressOfIBInterfaceByName(String ibname) throws SocketException {
        NetworkInterface ibif = NetworkInterface.getByName(ibname);
        Enumeration<InetAddress> inetAddresses = ibif.getInetAddresses();
        for (InetAddress inetAddress : Collections.list(inetAddresses)) {
            if (inetAddress.toString().indexOf(":") == -1) {
                return inetAddress.toString().substring(1);
            }
        }
        return "";
    }
}
