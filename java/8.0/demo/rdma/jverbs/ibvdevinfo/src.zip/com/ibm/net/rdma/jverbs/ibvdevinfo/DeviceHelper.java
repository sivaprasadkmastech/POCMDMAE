/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.ibvdevinfo;

import com.ibm.net.rdma.jverbs.verbs.Device;
import com.ibm.net.rdma.jverbs.verbs.DeviceAttribute;
import com.ibm.net.rdma.jverbs.verbs.PortAttribute;

/**
 * Helper functions to get understandable device information which are not part of headers.
 * Mimics devinfo.c of ibv_devinfo tool
 *
 */
class DeviceHelper {
	public static String getTransportStr(Device.TransportType transportType) {
        switch(transportType) {
            case IBV_TRANSPORT_IB:    return "InfiniBand";
            case IBV_TRANSPORT_IWARP: return "iWARP";
            default:                  return "invalid transport";
        }
    }

    public static String getAutomicCapStr(DeviceAttribute.AtomicLimit automicCap) {
        switch (automicCap) {
            case IBV_ATOMIC_NONE: return "ATOMIC_NONE";
            case IBV_ATOMIC_HCA:  return "ATOMIC_HCA";
            case IBV_ATOMIC_GLOB: return "ATOMIC_GLOB";
			case IBV_EXP_ATOMIC_HCA_REPLY_BE: return "ATOMIC_HCA_REPLY_BE";
            default:              return "invalid atomic capability";
        }
    }
    
    public static String getGuidStr(long guid) {
         return(String.format("%04x:%04x:%04x:%04x",
             (guid >> 48) & 0xffff,
             (guid >> 32) & 0xffff,
             (guid >> 16) & 0xffff,
             (guid >>  0) & 0xffff));
    } 

    public static String getLinkLayerStr(int link_layer) {
          switch (link_layer) {
              case 0:
              case 1:
                 return "IB";
              case 2:
                 return "Ethernet";
              default:
                 return "Unknown";
         }
    }

    public static String getMtuStr(PortAttribute.Mtu max_mtu) {
         switch (max_mtu) {
         	case IBV_MTU_256:  return "256";
         	case IBV_MTU_512:  return "512";
         	case IBV_MTU_1024: return "1024";
         	case IBV_MTU_2048: return "2048";
         	case IBV_MTU_4096: return "4096";
         	default:           return "invalid MTU";
         }
   }

   public static String getPortStateStr(PortAttribute.PortState pstate) {
	   switch (pstate) {
	   	case IBV_PORT_DOWN:   return "PORT_DOWN";
	   	case IBV_PORT_INIT:   return "PORT_INIT";
	   	case IBV_PORT_ARMED:  return "PORT_ARMED";
	   	case IBV_PORT_ACTIVE: return "PORT_ACTIVE";
	   	default:              return "invalid state";
	   }
   }

   public static String getVlStr(short vl_num) {
	   switch (vl_num) {
	   	case 1:  return "1";
	   	case 2:  return "2";
	   	case 3:  return "4";
	   	case 4:  return "8";
	   	case 5:  return "15";
	   	default: return "invalid value";
	   }
   }

   public static String getSpeedStr(short speed) {
	   switch (speed) {
	   	case 1:  return "2.5 Gbps";
	   	case 2:  return "5.0 Gbps";
	   	case 4: 
	   	case 8:  return "10.0 Gbps";
	   	case 16: return "14.0 Gbps";
	   	case 32: return "25.0 Gbps";
	   	default: return "invalid speed";
	   }
    }

    public static String getWidthStr(short width) {
    	switch (width) {
    		case 1:  return "1";
    		case 2:  return "4";
    		case 4:  return "8";
    		case 8:  return "12";
    		default: return "invalid width";
    	}
    }       

   public static String getPortPhyStateStr(short phys_state) {
	   switch (phys_state) {
	   	case 1:  return "SLEEP";
	   	case 2:  return "POLLING";
	   	case 3:  return "DISABLED";
	   	case 4:  return "PORT_CONFIGURATION TRAINNING";
	   	case 5:  return "LINK_UP";
	   	case 6:  return "LINK_ERROR_RECOVERY";
	   	case 7:  return "PHY TEST";
	   	default: return "invalid physical state";
	   }
   }

   public static boolean isNotNull(byte[] raw) {
       if ((raw[8] | raw[9] | raw[10] | raw[11] | raw[12] | raw[13] | raw[14] | raw[15]) == 0) {
    	   return true;
       } else {
    	   return false;
       }
   }
}
