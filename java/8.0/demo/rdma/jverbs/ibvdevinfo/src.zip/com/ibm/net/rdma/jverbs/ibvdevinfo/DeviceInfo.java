/*========================================================================
 * IBM Confidential
 * OCO Source Materials
 *
 * IBM SDK, Java(tm) Technology Edition, v8
 * (C) Copyright IBM Corp. 2014, 2015. All Rights Reserved
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright office.
 *========================================================================
 */
package com.ibm.net.rdma.jverbs.ibvdevinfo;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.ibm.net.rdma.jverbs.verbs.Device;
import com.ibm.net.rdma.jverbs.verbs.DeviceAttribute;
import com.ibm.net.rdma.jverbs.verbs.DeviceGlobalId;
import com.ibm.net.rdma.jverbs.verbs.DeviceList;
import com.ibm.net.rdma.jverbs.verbs.PortAttribute;
import com.ibm.net.rdma.jverbs.verbs.VerbsContext;

/**
 * Display device information output same as ibv_devinfo -v
 * 
 * @author Sivasakthi <sithirug@in.ibm.com>
 * 
 */
final class DeviceInfo {

    boolean verboseFlag = false; // Check if -v (verbose) arg is specified
    boolean listFlag = false; // Check if -l (list) arg is specified
    String deviceNameArg = null; // Device name arg value -d <device> if supplied
    String portArg = null; // Port name arg value -i <port> if supplied

    /** 
     * Parse the passed argument
     * @param args
     * @return
     * @throws Exception
     */
    private boolean parseArgs(String[] args) throws Exception {
        String arg;
        int i = 0;
        boolean isValid = true;

        if (args.length == 0) {
            return isValid;
        }
        while (i < args.length && args[i].startsWith("-")) {
            arg = args[i++];

            if (arg.equals("-v")) {
                verboseFlag = true;
            } else if (arg.equals("-l")) {
                listFlag = true;
            } else if (arg.equals("-d")) {
                if (i < args.length) {
                    deviceNameArg = args[i++];
                } else {
                    isValid = false;
                }
            } else if (arg.equals("-i")) {
                if (i < args.length) {
                    portArg = args[i++];
                } else {
                    isValid = false;
                }
            } else {
                isValid = false;
            }
        }
        return isValid;

    }

    public static void main(String[] args) throws Exception {
        DeviceInfo deviceInfo = new DeviceInfo();
        boolean isValidArgs = deviceInfo.parseArgs(args);
        if (isValidArgs) {
            deviceInfo.printDeviceInfoDetails(deviceInfo.getDeviceDetails());
        } else {
            usage();
        }
    }

    /**
     * Prints usage in cade of invalid argument
     */
    private static void usage() {
        System.err.printf("DeviceInfo [-v] { [-d device] [-i port] } | [-l]\n");
        System.err.printf("\t-v\t\tprints all the attributes of the Rdma devices.\n");
        System.err
                .printf("\t-d device\tuse the specified Rdma device. By default, the first device that is found is used\n");
        System.err.printf("\t-i port\t\tuse the specified port of Rdma device (default all ports)\n");
        System.err.printf("\t-l\t\tprint only the Rdma devices names\n");
    }

    /**
     * Read the device list, detail and form string 
     * @return
     * @throws IOException
     */
    private String getDeviceDetails() throws IOException {

        DeviceList devList = DeviceList.getDeviceList();
        StringBuilder sb = new StringBuilder();

        if (devList == null || (devList.getNdevices() == 0)) {
            sb.append("No Rdma devices found \n");
            return sb.toString();
        }
        boolean deviceFound = false;

        for (int i = 0; i < devList.getNdevices(); i++) {
            Device dev = devList.getDevice(i);
            VerbsContext ctx = dev.getContext();

            DeviceAttribute devAttr = ctx.queryDevice();
            String deviceName = dev.getDeviceName();
            if (!listFlag && deviceNameArg != null && !deviceNameArg.equals(deviceName)) {
                continue;
            }

            sb.append(String.format("hca_id:\t%s\n", deviceName));
            deviceFound = true;

            if (listFlag) {
                continue;
            }
            sb.append(String.format("\ttransport:\t\t\t%s (%d)\n",
                    DeviceHelper.getTransportStr(dev.getTransportType()), dev.getTransportType().getValue()));
            sb.append(String.format("\tfw_ver:\t\t\t\t%s\n", devAttr.getFirmwareVersion()));

            sb.append(String.format("\tnode_guid:\t\t\t%s\n", DeviceHelper.getGuidStr(dev.getDeviceGuid())));
            sb.append(String.format("\tsys_image_guid:\t\t\t%s\n",
                    DeviceHelper.getGuidStr(devAttr.getSystemImageGuid())));
            String vendor_id_hex = String.format("0x%4s\n", Integer.toHexString(devAttr.getVendorId())).replace(' ',
                    '0');
            sb.append(String.format("\tvendor_id:\t\t\t%s\n", vendor_id_hex));
            sb.append(String.format("\tvendor_part_id:\t\t\t%s\n", devAttr.getVendorPartId()));
            String hw_ver_hex = String.format("0x%2s\n", Integer.toHexString(devAttr.getHardwareVersion()))
                    .replace(' ', '0').toUpperCase();
            sb.append(String.format("\thw_ver:\t\t\t\t%s\n", hw_ver_hex));

            String board_id = new Scanner(new File(dev.getIbvDevicePath() + "/board_id")).useDelimiter("\\Z").next();
            sb.append(String.format("\tboard_id:\t\t\t%s\n", board_id));
            int nPorts = devAttr.getPhysicalPortCount();
            sb.append(String.format("\tphys_port_cnt:\t\t\t%s\n", nPorts));

            if (verboseFlag) {
                appendMoreDeviceAttributes(sb, devAttr);
            }

            /* Check if supplied portArg exists and if not then display all ports */
            boolean displayAllPorts = true;

            for (int port = 1; port <= nPorts; port++) {
                if (portArg != null && (portArg.equals("" + port))) {
                    displayAllPorts = false;
                }
            }
            /* Iterate through port and print port attributes for each port */
            PortAttribute portAttr = null;
            for (int port = 1; port <= nPorts; port++) {
                portAttr = ctx.queryPort(port);
                if (!displayAllPorts && portArg != null && !(portArg.equals("" + port))) {
                    continue;
                }
                sb.append(String.format("\t\tport:\t%d\n", port));

                sb.append(String.format("\t\t\tstate:\t\t\t%s (%d)\n",
                        DeviceHelper.getPortStateStr(portAttr.getState()), portAttr.getState().ordinal()));
                sb.append(String.format("\t\t\tmax_mtu:\t\t%s (%d)\n", DeviceHelper.getMtuStr(portAttr.getMaxMtu()),
                        portAttr.getMaxMtu().ordinal()));
                sb.append(String.format("\t\t\tactive_mtu:\t\t%s (%d)\n",
                        DeviceHelper.getMtuStr(portAttr.getActiveMtu()), portAttr.getActiveMtu().ordinal()));
                sb.append(String.format("\t\t\tsm_lid:\t\t\t%d\n", portAttr.getSmLid()));
                sb.append(String.format("\t\t\tport_lid:\t\t%d\n", portAttr.getLid()));
                sb.append(String.format("\t\t\tport_lmc:\t\t0x%02x\n", portAttr.getLmc()));
                sb.append(String.format("\t\t\tlink_layer:\t\t%s\n",
                        DeviceHelper.getLinkLayerStr(portAttr.getLinkLayer())));

                if (verboseFlag) {
                    appendMorePortAttributes(sb, dev, ctx, portAttr, port);
                }
            }
        }
        if (!listFlag && deviceNameArg != null && !deviceFound) {
            sb.append("Rdma device '" + deviceNameArg + "' wasn't found \n");
        }
        devList.freeDeviceList();
        return sb.toString();
    }

    /**
     * Display port attribute in case of verbose output
     * @param sb
     * @param dev
     * @param ctx
     * @param portAttr
     * @param port
     * @throws IOException
     */
    private void appendMorePortAttributes(StringBuilder sb, Device dev, VerbsContext ctx, PortAttribute portAttr,
            int port) throws IOException {
        sb.append(String.format("\t\t\tmax_msg_sz:\t\t0x%x\n", portAttr.getMaxMessageSize()));
        sb.append(String.format("\t\t\tport_cap_flags:\t\t0x%08x\n", portAttr.getPortCapFlags()));
        sb.append(String.format("\t\t\tmax_vl_num:\t\t%s (%d)\n",
                DeviceHelper.getVlStr(portAttr.getMaxVlNum()), portAttr.getMaxVlNum()));

        sb.append(String.format("\t\t\tbad_pkey_cntr:\t\t0x%x\n", portAttr.getBadPkeyConuter()));
        sb.append(String.format("\t\t\tqkey_viol_cntr:\t\t0x%x\n", portAttr.getQkeyViolationCounter()));
        sb.append(String.format("\t\t\tsm_sl:\t\t\t%d\n", portAttr.getSmSl()));
        sb.append(String.format("\t\t\tpkey_tbl_len:\t\t%d\n", portAttr.getPkeyTableLength()));
        sb.append(String.format("\t\t\tgid_tbl_len:\t\t%d\n", portAttr.getGidTableLength()));
        sb.append(String.format("\t\t\tsubnet_timeout:\t\t%d\n", portAttr.getSubnetTimeout()));
        sb.append(String.format("\t\t\tinit_type_reply:\t%d\n", portAttr.getInitTypeReply()));

        sb.append(String.format("\t\t\tactive_width:\t\t%sX (%d)\n",
                DeviceHelper.getWidthStr(portAttr.getActiveWidth()), portAttr.getActiveWidth()));
        sb.append(String.format("\t\t\tactive_speed:\t\t%s (%d)\n",
                DeviceHelper.getSpeedStr(portAttr.getActiveSpeed()), portAttr.getActiveSpeed()));

        if (dev.getTransportType() == Device.TransportType.IBV_TRANSPORT_IB) {
            sb.append(String.format("\t\t\tphys_state:\t\t%s (%d)\n",
                    DeviceHelper.getPortPhyStateStr(portAttr.getPhysicalState()),
                    portAttr.getPhysicalState()));
        }

        DeviceGlobalId gid;
        for (int j = 0; j < portAttr.getGidTableLength(); j++) {
            gid = ctx.queryGid(port, j);
            byte[] raw = gid.getRaw();
            if (raw != null && !DeviceHelper.isNotNull(raw)) {
                sb.append(String
                        .format("\t\t\tGID[%3d]:\t\t%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x\n",
                                j, raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7], raw[8],
                                raw[9], raw[10], raw[11], raw[12], raw[13], raw[14], raw[15]));
            }
        }
    }

    /**
     * Display more device attributes in case of verbose
     * @param sb
     * @param devAttr
     */
    private void appendMoreDeviceAttributes(StringBuilder sb, DeviceAttribute devAttr) {
        String max_mr_size_hex = String.format("0x%11s\n", Long.toHexString(devAttr.getMaxMemoryRegionSize()))
                .replace(' ', '0');
        sb.append(String.format("\tmax_mr_size:\t\t\t%s\n", max_mr_size_hex));

        String page_size_cap_hex = String.format("0x%s\n", Long.toHexString(devAttr.getPageSizeLimit()))
                .replace(' ', '0');
        sb.append(String.format("\tpage_size_cap:\t\t\t%s\n", page_size_cap_hex));
        sb.append(String.format("\tmax_qp:\t\t\t\t%d\n", devAttr.getMaxQueuePair()));
        sb.append(String.format("\tmax_qp_wr:\t\t\t%d\n", devAttr.getMaxQueuePairWorkRequest()));
        String device_cap_flags_hex = String
                .format("0x%8s\n", Integer.toHexString(devAttr.getDeviceCapFlags())).replace(' ', '0');
        sb.append(String.format("\tdevice_cap_flags:\t\t%s\n", device_cap_flags_hex));

        sb.append(String.format("\tmax_sge:\t\t\t%d\n", devAttr.getMaxSge()));
        sb.append(String.format("\tmax_sge_rd:\t\t\t%d\n", devAttr.getMaxSgeRd()));
        sb.append(String.format("\tmax_cq:\t\t\t\t%d\n", devAttr.getMaxCompletionQueue()));
        sb.append(String.format("\tmax_cqe:\t\t\t%d\n", devAttr.getMaxCompletionQueueEvents()));
        sb.append(String.format("\tmax_mr:\t\t\t\t%d\n", devAttr.getMaxMemoryRegion()));
        sb.append(String.format("\tmax_pd:\t\t\t\t%d\n", devAttr.getMaxProtectionDomains()));
        sb.append(String.format("\tmax_qp_rd_atom:\t\t\t%d\n", devAttr.getMaxQpRdAtom()));
        sb.append(String.format("\tmax_ee_rd_atom:\t\t\t%d\n", devAttr.getMaxEeRdAtom()));
        sb.append(String.format("\tmax_res_rd_atom:\t\t%d\n", devAttr.getMaxResRdAtom()));
        sb.append(String.format("\tmax_qp_init_rd_atom:\t\t%d\n", devAttr.getMaxQpInitRdAtom()));
        sb.append(String.format("\tmax_ee_init_rd_atom:\t\t%d\n", devAttr.getMaxEeInitRdAtom()));
        sb.append(String.format("\tatomic_cap:\t\t\t%s (%d)\n",
                DeviceHelper.getAutomicCapStr(devAttr.getAtomicCap()), devAttr.getAtomicCap().ordinal()));
        sb.append(String.format("\tmax_ee:\t\t\t\t%d\n", devAttr.getMaxEe()));
        sb.append(String.format("\tmax_rdd:\t\t\t%d\n", devAttr.getMaxRdd()));
        sb.append(String.format("\tmax_mw:\t\t\t\t%d\n", devAttr.getMaxMw()));
        sb.append(String.format("\tmax_raw_ipv6_qp:\t\t%d\n", devAttr.getMaxRawIpv6Qp()));
        sb.append(String.format("\tmax_raw_ethy_qp:\t\t%d\n", devAttr.getMaxRawEthernetQp()));
        sb.append(String.format("\tmax_mcast_grp:\t\t\t%d\n", devAttr.getMaxMcastGrp()));
        sb.append(String.format("\tmax_mcast_qp_attach:\t\t%d\n", devAttr.getMaxMcastQpAttach()));
        sb.append(String.format("\tmax_total_mcast_qp_attach:\t%d\n", devAttr.getMaxTotalMcastQpAttach()));
        sb.append(String.format("\tmax_ah:\t\t\t\t%d\n", devAttr.getMaxAh()));
        sb.append(String.format("\tmax_fmr:\t\t\t%d\n", devAttr.getMaxFmr()));
        if (devAttr.getMaxFmr() != 0)
            sb.append(String.format("\tmax_map_per_fmr:\t\t%d\n", devAttr.getMaxMapPerFmr()));
        sb.append(String.format("\tmax_srq:\t\t\t%d\n", devAttr.getMaxSrq()));
        sb.append(String.format("\tmax_srq_wr:\t\t\t%d\n", devAttr.getMaxSrqWorkRequest()));
        sb.append(String.format("\tmax_srq_sge:\t\t\t%d\n", devAttr.getMaxSrqSge()));
        sb.append(String.format("\tmax_pkeys:\t\t\t%s\n", devAttr.getMaxPkeys()));
        sb.append(String.format("\tlocal_ca_ack_delay:\t\t%d\n", devAttr.getLocalCaAckDelay()));
    }

    /**
     * Print the string which holds the detail
     * @param deviceInfoDetails
     */
    private void printDeviceInfoDetails(String deviceInfoDetails) {
        System.out.print(deviceInfoDetails);
    }
}
